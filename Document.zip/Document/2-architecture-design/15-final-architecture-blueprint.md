# Doc 15 — SataRobo FINAL Project Blueprint (v2 — BẢN THỐNG NHẤT)

> **Vai trò:** tài liệu CHỐT DUY NHẤT cho toàn bộ hệ thống satarobo-vn — hợp nhất: Doc 15 v1 (blueprint kỹ thuật trước/sau + sơ đồ) + `15-satarobo-final-project-blueprint-v1.md` (CEO chốt nghiệp vụ 05/06/2026) + Doc 13/14.
> Tài liệu này **thay thế các bản yêu cầu rời rạc trước đó**. Requirement đã loại bỏ KHÔNG đưa lại vào core. Khi xung đột với tài liệu khác → **file này thắng**.
> **Phạm vi:** `satarobo.vn` · `admin.satarobo.vn` · `hocvien.satarobo.vn`.
> **Cập nhật:** 2026-06-05.

---

## §0 — QUYẾT ĐỊNH CHIẾN LƯỢC ĐÃ CHỐT

| # | Nhóm | Quyết định cuối |
|---|---|---|
| Q1 | Kiến trúc | **Modular Monolith** trên Next.js/Vercel — không microservice |
| Q2 | Tổ chức | `OrgUnit` tree (HO/REGION/CENTER/CAMPUS/PARTNER/FRANCHISE). Thực tế hiện tại: **HO + CS1 (211 Nguyễn Hữu Thọ) + CS2 (114 Hoàng Diệu)**; CS2 vừa là center vừa là nơi HO làm việc |
| Q3 | Phân quyền | **Dynamic RBAC** (`RoleDef/RolePermission/UserOrgRole`) + **Scope 6 mức** (GLOBAL/CENTER/CLASS/OWN/CHILDREN/ASSIGNED) + giữ per-user grant ALLOW/DENY (5.3) |
| Q4 | Event | **DomainEvent outbox + cron dispatcher** — không message broker. **Tiền/invoice/payment/enrollment đi TRANSACTION, không đi event async** |
| Q5 | Schema | **Multi-file Prisma** (`prisma/schema/*.prisma`) — không tách Postgres schema vật lý |
| Q6 | Tenant | Hoãn `tenantId` — bảng mới có `orgUnitId`; backfill khi có đối tác SaaS thật |
| Q7 | Audit | **AuditLog hợp nhất 1 bảng** cho dữ liệu mới; 8 bảng cũ đọc-only |
| Q8 | Integration | Mọi external call qua `modules/integration` (Meta Messenger/Ads, Resend, R2; sau: SMS, Zalo, MISA, VNPay) |
| Q9 | Login | **Cổng login chung `satarobo.vn/login`** → tự nhận role redirect: staff (`hovaten@satarobo.vn`) → admin; parent (phone/email) → hocvien |
| Q10 | Portal | `hocvien.satarobo.vn` = phụ huynh + học sinh chung 1 tài khoản — **site phụ huynh + site từng con**; route đẹp **KHÔNG lộ `studentId`** (active profile trong signed cookie). KHÔNG student login riêng, KHÔNG teacher domain riêng |
| Q11 | Lead | **Messenger Ads qua Page HO là kênh CHÍNH** (webhook → conversation → L1); phụ: GForm, landing, web form, import, giới thiệu |
| Q12 | Khóa học | Core = **offline Sata 1–8 + Combo Sata 1&2**. Online course **trỏ Sataworld** — không build video LMS |
| Q13 | OTP/Activation | KHÔNG mật khẩu mặc định. Core: activation qua **Resend email**, parent tự đặt mật khẩu; OTP provider abstraction để cắm SMS/Zalo sau |
| Q14 | Payment | Core: ghi nhận thanh toán **thủ công + kế toán xác nhận** — không cổng online |
| Q15 | Roadmap | **A0 → R1 (CRM Messenger + Marketing + Commission) → R2 (SIS/Finance) → R3 (LMS offline) → R4 (Portal) → R5 (HR)** → backlog |

### Đã LOẠI khỏi core (không đưa lại)

| Nhóm | Mục loại bỏ | Thay thế |
|---|---|---|
| Pháp lý dữ liệu trẻ em | AI camera/face recognition, phân tích sức khỏe, sinh trắc học, geofencing/IoT/định vị **học sinh** | Điểm danh thủ công bởi GV/admin + PH báo vắng + lịch sử chỉnh sửa. Geofence CHỈ cho nhân viên (R5) |
| Quá xa MVP | Web3/NFT/IPFS, SataCoin blockchain, Learn2Earn, Marketplace, SaaS/White-label/Franchise billing | Chứng chỉ PDF + mã tra cứu; điểm thưởng/badge nội bộ (backlog) |
| AI (toàn bộ) | AI Tutor/CRM Assistant/Reporting/Learning path/Prediction | Rule-based: `nextCourseId`, RiskAlert, Class Health Score |
| Sai quyết định cũ | FB Lead Form là main flow → **Messenger**; student login riêng → profile trong tài khoản PH; teacher domain riêng → admin theo role; route có studentId → active profile; `User.centerId` → OrgUnit |

### Backlog phase sau (thứ tự đề xuất)

`1. Zalo OA/ZNS → 2. Payment gateway → 3. MISA AMIS → 4. Flutter app + push → 5. AI assistant/reporting → 6. Franchise/SaaS`

### Wording chuẩn scope core

> Phạm vi phase core tập trung vận hành trung tâm đào tạo offline: CRM tuyển sinh từ Messenger Ads theo LEADS_1/2/3, phân quyền HO/CS1/CS2, quản lý học viên/phụ huynh, LMS offline, học phí/công nợ, báo cáo, portal phụ huynh + học sinh. Sinh trắc học trẻ em, AI camera, định vị học sinh, blockchain/NFT, marketplace, app mobile, MISA/Zalo/VNPay live, AI prediction **không thuộc core** — chỉ xem xét sau khi core hoàn thiện và có đánh giá pháp lý/kỹ thuật riêng.

---

## §1 — PHÂN TÍCH **TRƯỚC** UPDATE (AS-IS) — vì sao phải đổi

### 1.1 Kiến trúc hiện tại

```mermaid
flowchart TB
    subgraph FE["Frontend (route groups)"]
        PUB["(public) + (legacy)"]
        ADM["(admin)/admin — 80+ pages"]
        POR["(portal)/portal"]
    end
    MW["proxy.ts — host×role TĨNH (8 role enum)<br/>login RIÊNG từng host"]
    subgraph CODE["1 khối code phẳng"]
        ACT["app/**/actions.ts (~20 file)<br/>auth + validate + BUSINESS + side-effects TRỘN"]
        PERM["lib/auth/permissions.ts<br/>GOD-FILE: 140 action × 8 role hardcode"]
    end
    DB[("schema.prisma — 1 FILE 138 models")]
    EXT["Resend/Zalo/MISA/CAPI/GA4 gọi INLINE rải rác"]
    FE --> MW --> CODE --> DB
    ACT -.-> EXT
```

### 1.2 Sơ đồ coupling hiện tại

```mermaid
flowchart LR
    A[createLead]:::hot -->|inline| B[dedup] & C[auto-assign] & D[email] & E[Meta CAPI] & F[GA4]
    G[markAttendance]:::hot -->|inline| H[MakeupNeed] & I[notify PH] & J[RiskAlert] & K[SataCoin]
    L[confirmOrder]:::hot -->|inline| M[Enrollment] & N[trừ kho] & O[Voucher] & P[EmailQueue] & Q[MISA log]
    classDef hot fill:#fdd,stroke:#c00
```

### 1.3 ERD identity hiện tại

```mermaid
erDiagram
    User {
        enum role "HARDCODE 8 gia tri"
        enum-array roles "va da vai tro"
        string centerId FK "phang - KHONG co HO"
        int tokenVersion "va invalidation"
    }
    Center { string id PK }
    UserPermissionGrant { enum grant "ALLOW-DENY da DB-driven (GIU)" }
    User }o--|| Center : centerId
    User ||--o{ UserPermissionGrant : grants
```

### 1.4 Tổng hợp vấn đề (P1–P8 + lỗ hổng đã vá bằng Q-quyết định)

| Vấn đề | Hệ quả | Giải bằng |
|---|---|---|
| P1 Role enum, không có HO | Không biểu diễn "Kế toán Hội sở"; thêm role = deploy | Q2 + Q3 |
| P2 Matrix hardcode god-file | Module mới nào cũng sửa 1 file | Q3 (RolePermission DB) |
| P3 Scope center ad-hoc | Nguy cơ CS1 thấy doanh số CS2 | `scopedDb` (§6.3) |
| P4 Side-effects inline | Thêm consumer = mổ action gốc | Q4 (outbox) |
| P5 Logic trong actions | Commission không unit-test được | Module template (§6.2) |
| P6 1 schema 138 models | Thêm model khó | Q5 (multi-file) |
| P7 8 bảng audit lặp + 3 kiểu notify | Copy-paste tăng dần | Q7 + Notifier |
| P8 JWT chứa role/grants | Đổi quyền không hiệu lực ngay | Session gọn (§6.4) |
| Login riêng từng host | Trải nghiệm rời rạc, không đúng Q9 | Login chung (§3) |
| Luồng tiền nếu đi event (lỗi C1 đã chặn) | Lệch sổ | Q4 transaction rule |

---

## §2 — TỔ CHỨC & PHÂN QUYỀN (SAU UPDATE)

### 2.1 Cây tổ chức thực tế

```mermaid
flowchart TD
    T[Tenant: SataRobo] --> HO["OrgUnit HO — Hội sở<br/>(làm việc tại địa chỉ CS2)"]
    HO --> CS1["OrgUnit CS1 — CENTER<br/>211 Nguyễn Hữu Thọ, Đà Nẵng"]
    HO --> CS2["OrgUnit CS2 — CENTER<br/>114 Hoàng Diệu, Đà Nẵng"]
    HO -.tương lai.-> FR["PARTNER / FRANCHISE / REGION"]
```

**Nguyên tắc:** CS2 = center đào tạo; HO = đơn vị điều hành **độc lập** (tính chi phí/lương riêng — open item OI-1, mặc định CÓ). Một nhân viên có thể thuộc cả HO và CS2.

### 2.2 ERD identity/org đích

```mermaid
erDiagram
    OrgUnit {
        string id PK
        enum type "HO-REGION-CENTER-CAMPUS-PARTNER-FRANCHISE"
        string code UK "HO - CS1 - CS2"
        string name
        string address
        string parentId FK "tree"
        string centerId UK "PhaseA: link 1-1 Center cu"
        bool isActive
    }
    RoleDef {
        string code UK "CENTER_MANAGER, SALE_ADMIN..."
        string name "ten tieng Viet"
        bool isSystem "SUPER_ADMIN, PARENT khong xoa"
    }
    RolePermission {
        string action "validate bang ACTION_REGISTRY"
        enum scopeType "GLOBAL-CENTER-CLASS-OWN-CHILDREN-ASSIGNED"
    }
    UserOrgRole {
        string userId PK
        string orgUnitId PK "quyen GAN VOI vi tri trong cay"
        string roleId PK
    }
    EmployeeOrgAssignment {
        string employeeId
        string orgUnitId
        string roleInOrg
        date startDate
        date endDate
        bool isPrimary
        int allocationPercent "phan bo luong-chi phi"
    }
    User { int sessionVersion "JWT chi con userId+sessionVersion" }
    UserPermissionGrant { enum grant "ALLOW-DENY giu tu 5.3" }

    OrgUnit ||--o{ OrgUnit : "parent-children"
    User ||--o{ UserOrgRole : has
    OrgUnit ||--o{ UserOrgRole : at
    RoleDef ||--o{ UserOrgRole : as
    RoleDef ||--o{ RolePermission : grants
    User ||--o{ UserPermissionGrant : overrides
    OrgUnit ||--o{ EmployeeOrgAssignment : staffing
```

**Phân biệt 2 bảng gán:** `UserOrgRole` = **quyền truy cập hệ thống** (RBAC) · `EmployeeOrgAssignment` = **nhân sự/chi phí** (kiêm nhiệm HO+CS2, GV CS2 dạy thay CS1, % phân bổ lương, báo cáo lợi nhuận per cơ sở).

### 2.3 Bộ role khởi điểm (seed)

| Nhóm | Role | Quyền chính |
|---|---|---|
| HO | `SUPER_ADMIN`* | Toàn hệ thống, quản role |
| HO | `HO_MANAGER` (TGĐ) | Dashboard/báo cáo toàn hệ thống theo quyền cấp |
| HO | `HO_ACCOUNTANT` | Tài chính, phân bổ chi phí, hoa hồng toàn hệ thống |
| HO | `HO_HR` | Nhân sự toàn hệ thống |
| HO | `QC_MARKETING` | Ads, campaign, dashboard marketing — **không xem PII nếu không cần** |
| HO | `SALE_ADMIN` | Trực Messenger, tạo LEADS_2, bàn giao trung tâm |
| Center | `CENTER_MANAGER` | Toàn bộ dữ liệu center mình |
| Center | `CENTER_SALES_CSM` | Lead/HV được giao, pipeline, chăm sóc, tái tục (gộp Sale+CSM+CRM) |
| Center | `TEACHER`, `ASSISTANT_TEACHER` | Lớp mình dạy: điểm danh, nhận xét, bài tập, media |
| Center | `CENTER_ACCOUNTANT` | Học phí/công nợ/thanh toán center mình |
| Portal | `PARENT`* | Chỉ dữ liệu con mình (scope CHILDREN) |

(*) `isSystem` — không xóa được. Học sinh **không có account riêng** trong core.

### 2.4 Luồng resolve quyền

```mermaid
flowchart TD
    A["can(actor, action, target?)"] --> B{SUPER_ADMIN @ HO?}
    B -->|có| OK[✅]
    B -->|không| C{Grant DENY?} -->|có| NO[❌]
    C -->|không| D{Grant ALLOW?} -->|có| OK
    D -->|không| E{RolePermission có action<br/>tại OrgUnit tổ tiên/chính của target?}
    E -->|không| NO
    E -->|có| F{scopeType vs target}
    F -->|GLOBAL| OK
    F -->|"CENTER: target ∈ subtree"| OK
    F -->|"CLASS/ASSIGNED: được phân công"| OK
    F -->|"OWN: mình tạo/phụ trách"| OK
    F -->|"CHILDREN: con mình"| OK
    F -->|sai| NO
```

---

## §3 — DOMAIN, LOGIN CHUNG & PORTAL

### 3.1 Domain & login chung (Q9 — THAY ĐỔI so với hiện tại)

```mermaid
sequenceDiagram
    participant U as User
    participant L as satarobo.vn/login (CỔNG CHUNG)
    participant RP as decideRoute (route-policy v2)
    U->>L: đăng nhập
    alt Staff — email công ty hovaten@satarobo.vn
        L->>RP: session có staff role
        RP-->>U: redirect → admin.satarobo.vn
    else Parent — phone/email
        L->>RP: role PARENT
        RP-->>U: redirect → hocvien.satarobo.vn
    end
    Note over RP: vào thẳng admin./hocvien. chưa login<br/>→ đẩy về satarobo.vn/login?callbackUrl=...<br/>⚠️ Sửa lib/auth/route-policy.ts + route-policy.test.ts<br/>(hiện tại login giữ nguyên host — phải đổi)
```

### 3.2 Portal phụ huynh + học sinh (Q10)

```
1 tài khoản PARENT → [ Site phụ huynh | Site con 1 | Site con 2 ... ]
- Site phụ huynh: chức năng PH (yêu cầu, đánh giá, học phí, consent)
- Site con N: CHỈ dữ liệu/chức năng của con N
- KHÔNG lộ studentId trên URL — active profile trong signed cookie (cơ chế ACTIVE_SITE đã có, giữ + mở rộng)
Route: /thong-bao /lich-hoc /bai-tap /trac-nghiem /nop-bai /hinh-anh /nhan-xet /danh-gia
```

---

## §4 — KIẾN TRÚC KỸ THUẬT ĐÍCH

### 4.1 Kiến trúc tổng thể

```mermaid
flowchart TB
    subgraph FE["Frontend Layer"]
        PUB["Public Website"]
        ADM["Admin Portal (HO + Center, TEACHER dùng chung)"]
        POR["Parent/Student Portal"]
    end
    subgraph GW["Gateway Layer"]
        MW["proxy.ts + decideRoute v2<br/>login chung + host routing"]
        AUTHZ["can() — RBAC/ABAC + scope"]
        RL["Rate limit"]
    end
    subgraph MODS["Application Modules (modules/*)"]
        ID[identity] 
        ORG[organization]
        CRM["crm<br/>Messenger·Lead·SLA"]
        COM["commission 💰"]
        SIS["sis<br/>Student·Parent·Enrollment"]
        LMS["lms (offline)<br/>Curriculum·Session·Attendance·Assignment·Media"]
        FIN["finance<br/>Invoice·Payment·Debt"]
        NOTI[notification]
        RPT[reporting]
        INT["integration 🔌"]
        SH["shared: audit·events·storage·pdf·excel"]
    end
    subgraph EVT["Event Layer"]
        OUT[("DomainEvent outbox")]
        DISP["Cron dispatcher"]
    end
    subgraph DATA["Data Layer"]
        SDB["scopedDb(actor)"]
        PG[("PostgreSQL — prisma/schema/*.prisma")]
        RD[("Upstash Redis")]
        R2[("R2/S3")]
        AUD[("AuditLog hợp nhất")]
    end
    FE --> GW --> MODS
    MODS -- "publish sau commit" --> OUT --> DISP -- "handlers idempotent" --> MODS
    MODS --> SDB --> PG
    MODS --> SH --> AUD
    MODS -- "CHỈ QUA" --> INT
    NOTI --> INT
    GW --> RD
    LMS --> R2
```

### 4.2 Cấu trúc code & ranh giới import (ESLint enforce)

```
modules/{identity, organization, crm, commission, sis, lms, attendance, finance,
         notification, reporting, integration, audit, shared}/
  └── index.ts (public API) · service.ts · repository.ts · events.ts · permissions.ts · validators.ts
```

```
✗ app/** import db trực tiếp            → đi qua module + scopedDb
✗ modules/A import sâu modules/B/**     → chỉ import modules/B (index)
✗ module nghiệp vụ gọi external API     → chỉ modules/integration
✓ mọi query user-facing qua scopedDb + can()
```

### 4.3 Multi-file Prisma (Q5)

```
prisma/schema/
├── base.prisma (datasource + generator, prismaSchemaFolder)
├── identity.prisma · organization.prisma · crm.prisma · commission.prisma
├── sis.prisma · lms.prisma · finance.prisma · engagement.prisma
├── hr.prisma · content.prisma · shared.prisma
```
(Di chuyển model giữa file = cắt-dán, không sinh migration.)

### 4.4 Data scope enforced

```mermaid
sequenceDiagram
    participant P as Page/Action
    participant AR as ActorResolver (per-request cache)
    participant S as scopedDb(actor)
    P->>AR: resolve(userId từ JWT)
    AR-->>P: Actor{permissions, visibleCenterIds = OrgUnit subtree}
    P->>S: scopedDb(actor).lead.findMany()
    S->>S: tự inject centerId IN visibleCenterIds (HO: bỏ qua)
    Note over P,S: CENTER_MANAGER CS1 không bao giờ thấy CS2<br/>ESLint chặn db trần → không thể "quên filter"
```

### 4.5 Event-driven nội bộ (Q4)

```prisma
model DomainEvent { id type payloadJson status(PENDING/PROCESSING/DONE/FAILED) attempts lastError createdAt processedAt }
```

**Danh mục event core:** `messenger.conversation.created` · `lead.qualified` · `lead.handed_to_center` · `lead.assigned_to_sale` · `lead.converted` · `invoice.created` · `payment.confirmed` · `parent.account.created` · `student.absent` · `course.completed` · `assignment.submitted` · `media.uploaded` · `marketing.cost_allocation.confirmed`

**Quy tắc phân loại (bắt buộc trong code review):**

| Trong TRANSACTION (atomic) | Qua EVENT (async, idempotent, retry) |
|---|---|
| `lead.converted` → tạo Parent/Student/Relation/Enrollment/Invoice/Payment | Gửi email/OTP activation |
| `payment.confirmed` → cập nhật invoice/debt/revenue | Cập nhật dashboard/funnel stats |
| Trừ kho khi xuất hàng | Alert SLA |
| | Commission stats draft |
| | Đồng bộ external (Ads insights, MISA sau này) |

```mermaid
flowchart LR
    subgraph TX["convertLead — 1 TRANSACTION (rollback toàn bộ nếu 1 bước lỗi)"]
        direction TB
        T0[Lead → ENROLLED + convertedAt/By] --> T1[ParentProfile + Student + Relation]
        T0 --> T2[Enrollment + Class enrollment]
        T0 --> T3["Invoice (INV-CS1-2026-0001) + Payment nếu đã thu"]
        T0 --> T4[AuditLog]
        T0 --> T5[("DomainEvent 'lead.converted'")]
    end
    T5 -.commit xong.-> D[Dispatcher]
    D --> H1[notification: email activation PH]
    D --> H2[commission: stats draft]
    D --> H3[reporting: funnel L3]
```

### 4.6 Session & quyền hiệu lực ngay

JWT chỉ còn `{userId, sessionVersion}` → ActorResolver đọc DB per-request (admin layout hiện đã query DB liveness — không tăng số query) → đổi role/quyền **hiệu lực request kế tiếp**, bỏ legacy shim + grants-in-token.

---

## §5 — CRM TUYỂN SINH (SR217 + Messenger-first)

### 5.1 Phễu & nguồn

```
LEADS_1 = tin nhắn/tương tác vào Page Messenger (kênh chính: Messenger Ads Page HO)
LEADS_2 = có SĐT + ghi chú → đủ điều kiện bàn giao trung tâm
LEADS_3 = đã đóng học phí = doanh số thực tế = cơ sở hoa hồng
Nguồn phụ: Google Form · landing · web form · import · PH giới thiệu · đối tác/sự kiện · data cũ
```

### 5.2 Model Messenger (thay `PageInboundEvent` bản cũ)

```prisma
model FacebookPageMapping { pageId scopeType(HO|CENTER) centerId? }   // Page HO nay; Page CS1/CS2 sau
model MessengerConversation { pageId psid parentName? phone? status firstMessageAt respondedAt leadId? }
model MessengerMessage { conversationId direction(IN|OUT) text attachments sentAt }
```

### 5.3 Workflow & state machine handover

```mermaid
stateDiagram-v2
    [*] --> LEADS_1: Messenger webhook tạo conversation
    LEADS_1 --> NEED_PHONE: Sale Admin chat theo kịch bản
    NEED_PHONE --> LEADS_2: có SĐT + ghi chú (qualifiedAt)
    LEADS_2 --> READY_TO_HANDOVER
    READY_TO_HANDOVER --> HANDED_TO_CENTER: chọn CS1/CS2 (handedAt)
    HANDED_TO_CENTER --> CENTER_ACCEPTED: QL TT xác nhận ≤30' (receivedConfirmedAt)
    CENTER_ACCEPTED --> ASSIGNED_TO_SALE: phân Sale/CSM (assignedAt)
    ASSIGNED_TO_SALE --> IN_PROGRESS: liên hệ ≤3h (firstContactAt)
    IN_PROGRESS --> ENROLLED: đóng học phí (LEADS_3, transaction §4.5)
    IN_PROGRESS --> NURTURING
    IN_PROGRESS --> LOST
    NURTURING --> IN_PROGRESS
```

**Mapping với `LeadStatus` enum hiện có (13 giá trị — KHÔNG đập):** trạng thái handover mới = **derive từ timestamps** (`qualifiedAt/handedAt/receivedConfirmedAt/assignedAt/firstContactAt/convertedAt`) + LeadStatus hiện hữu (NEW→ASSIGNED→CONTACTED→…→ENROLLED). `MessengerConversation` trước khi có SĐT **chưa phải Lead record** — L1 sống ở bảng conversation.

### 5.4 SLA chốt (bảng cuối — thay mọi con số cũ)

| Rule | Ngưỡng | Alert tới |
|---|---|---|
| SLA-0 Sale Admin phản hồi Messenger | mục tiêu **≤ 5 phút** (đo `respondedAt`) | SALE_ADMIN |
| SLA-1 L2 bàn giao TT | trong ngày, không qua đêm (**alert > 4h**) | SALE_ADMIN + CENTER_MANAGER |
| SLA-2 QL TT xác nhận + phân Sale | **≤ 30 phút** | CENTER_MANAGER |
| SLA-3 Sale liên hệ sau khi giao | **≤ 3 giờ** | CENTER_MANAGER (+Sale) |
| SLA-4 Lead không cập nhật trạng thái | **> 2 ngày** → cảnh báo | CENTER_MANAGER |
| SLA-5 Báo cáo tuần/tháng | T2 ≤17h / ngày 01 ≤17h | QL TT + HO_MANAGER |
| SLA-6 Chốt phân bổ CP | trước ngày 05 | HO_ACCOUNTANT |

Kịch bản Sale Admin chuẩn (xin SĐT + lớp/tuổi + chọn CS1/CS2/cần tư vấn) — lưu trong tài liệu vận hành, hệ thống hỗ trợ quick-reply.

### 5.5 Chart data — luồng số liệu CRM/Marketing

```mermaid
flowchart TD
    subgraph IN["Nguồn vào"]
        MS["Messenger webhook (Page HO)"] --> MC[(MessengerConversation/Message — L1)]
        ADS["Meta Ads Insights API (sync định kỳ)"] --> ST[(AdsInsightDaily: spend/impressions/clicks...)]
        QCF["Import thủ công (kênh chưa có API)"] --> ST
        SRC["GForm/landing/web form/import"] --> LD[(Lead — L2 timestamps)]
        MC -->|Sale Admin xin SĐT| LD
        ORD[("Invoice/Payment CONFIRMED — L3")]
    end
    LD -- "lead.* events" --> EV[(DomainEvent)] --> DISP[Dispatcher]
    ORD -- "payment.confirmed" --> EV
    DISP --> SLAH[SLA alerts] & FUN[Funnel stats] & COMH[Commission stats]
    MC & ST & FUN --> DASH["Marketing Dashboard<br/>Spend·CTR·CPC·CPM·conversations<br/>L1/L2/L3 · CPL=spend/L2 · CPA=spend/L3 · ROAS<br/>CR L1→L2, L2→L3<br/>Tabs: Tổng quan·HO/CS1/CS2·Campaign·Adset·Creative·Phân bổ·SLA"]
    ST & LD --> CAL[("CostAllocationPeriod<br/>DRAFT → CONFIRMED → REOPENED(SUPER_ADMIN/HO_ACCOUNTANT)<br/>CP_TT = CPL × L2 của TT")]
    COMH --> CP[("CommissionPeriod — 4 tầng trên L3<br/>QC 1% · SALE_ADMIN 1% · Sale/TVV 4% · CENTER_MANAGER 2% (max 8%)")]
    CP & CAL & DASH --> EXC[Export Excel + báo cáo tuần/tháng]
```

---

## §6 — SIS / FINANCE / LMS OFFLINE (tóm tắt chốt + delta với schema hiện tại)

### 6.1 Lead → Enrollment + Parent activation

- Transaction bắt buộc §4.5. Invoice code: `INV-{CENTER}-{YEAR}-{SEQ}` (dùng `Counter` hiện có). **Quyết định kỹ thuật: Invoice = mở rộng model `Order` hiện hữu** (đổi code format + ngữ nghĩa hiển thị) — không tạo model song song.
- Parent account: `PENDING_ACTIVATION` → email Resend → parent tự đặt mật khẩu (KHÔNG mật khẩu mặc định). OTP provider abstraction (`EMAIL` nay, `SMS/ZALO` cắm sau — model `OtpRequest` hiện có giữ).
- Duplicate phone: giữ dedup 90 ngày + UX hiển thị cho Sale.

### 6.2 Khóa học & gợi ý

Sata 1–8 + Combo 1&2 (model `Course/CoursePackage` hiện có). Gợi ý khóa tiếp: **rule-based `nextCourseId`** (Sata 3→4→…→8) — đã có nền `CoursePrerequisite/CourseCompletion.nextCourseId`. Online → link Sataworld.

### 6.3 LMS offline = vận hành đào tạo (không phải video LMS)

Chuỗi: Khóa → Giáo trình (**version, mỗi lớp gắn 1 curriculum version** — lớp cũ không bị ảnh hưởng khi đổi giáo trình) → Bài học → Lớp → Buổi → Điểm danh → Nhận xét → Media → Bài tập → Nộp → Chấm → Đánh giá năng lực → Báo cáo PH → CSM tái tục. Phần lớn model đã có (`Curriculum/Lesson/Class/ClassSession/...`).

**Delta cần làm so với schema hiện tại:**

| Hạng mục | Hiện tại | Chốt mới | Việc |
|---|---|---|---|
| ClassSession lesson | `lessonId` | `plannedLessonId` + `actualLessonId` (dạy lệch kế hoạch) | thêm cột, 2-phase |
| AttendanceStatus | PRESENT/ABSENT/LATE/EXCUSED | PRESENT/LATE/**ABSENT_EXCUSED/ABSENT_UNEXCUSED** | enum migration 2-phase (map ABSENT+EXCUSED) |
| Attendance rate | chưa chuẩn hóa | `presentCount=(PRESENT+LATE)/totalSessions COMPLETED` — Attendance là source of truth | helper + report |
| Teacher checklist sau buổi | checklist ck* rời | Điểm danh → xác nhận bài dạy → nhận xét → media+tag → giao bài → sự cố → **Hoàn tất buổi** | flow UI + trạng thái buổi |
| Assignment types | text/file | `IMAGE_UPLOAD/VIDEO_UPLOAD/FILE_UPLOAD/QUIZ/TEXT_ANSWER/PROJECT_SUBMISSION` + giao cho lớp/nhóm/cá nhân | mở rộng enum + targeting |
| Media | tag tùy chọn | **BẮT BUỘC tag**; PH chỉ xem media tag con; không tag = không hiển thị; duyệt + audit | enforce + consent |
| Consent | chưa có | `StudentConsent(type=CLASS_MEDIA, GRANTED/REVOKED, byParent)` — chưa consent thì lưu nội bộ, không public | model mới |
| Học bù | MakeupNeed có | + PH gửi yêu cầu bù, tìm buổi theo lesson/progress, **không học bù vượt tiến độ** | rule trong service |
| Giấy tờ tùy thân | — | **KHÔNG thu/lưu** (CMND/CCCD/khai sinh) — chỉ ảnh học viên + media lớp | policy |

### 6.4 Finance core

`Invoice(Order) · Payment · Debt · Refund · Tuition config · Revenue report · Cost allocation · Commission base`. Thanh toán: ghi nhận thủ công + kế toán xác nhận + Excel (Q14). Mọi mutation tiền → transaction + AuditLog.

### 6.5 HR (Phase R5 — nhân viên, KHÔNG học sinh)

QR động **30 giây + grace 5–10s**, GPS/geofence tại cơ sở, check-in/out, cảnh báo thiếu giờ, duyệt công (nền `EmployeeCheckin/Shift*` đã có).

---

## §7 — USE CASE DIAGRAMS (đích)

### 7.1 Hội sở

```mermaid
flowchart LR
    SA([SUPER_ADMIN]); HOM([HO_MANAGER]); HOA([HO_ACCOUNTANT]); QC([QC_MARKETING]); SAD([SALE_ADMIN @ HO])
    UC1((Tạo role + gán quyền qua UI)):::new; UC2((Gán user × OrgUnit × Role)):::new
    UC3((Dashboard toàn hệ thống — drill HO/CS1/CS2)):::new
    UC4((Duyệt hoa hồng 4 tầng)):::new; UC5((Chốt phân bổ CP — CONFIRMED/REOPEN)):::new
    UC6((Marketing dashboard: spend/CPL/CPA/ROAS)):::new
    UC7((Trực Messenger inbox — tạo L2, bàn giao)):::new
    UC8((Audit log hợp nhất)); UC9((Alert SLA + báo cáo trễ)):::new
    SA --> UC1 & UC2 & UC8
    HOM --> UC3 & UC4 & UC9
    HOA --> UC4 & UC5 & UC3
    QC --> UC6
    SAD --> UC7 & UC9
    classDef new fill:#dfd,stroke:#080
```

### 7.2 Trung tâm

```mermaid
flowchart LR
    CM([CENTER_MANAGER]); CS([CENTER_SALES_CSM]); GV([TEACHER / ASSISTANT_TEACHER]); CA([CENTER_ACCOUNTANT])
    U1((Xác nhận nhận lead ≤30' + phân Sale)):::new
    U2((Liên hệ ≤3h, pipeline, chốt L3 — transaction)):::new
    U3((Hoa hồng CỦA TÔI tạm tính)):::new
    U4((Checklist buổi học: điểm danh→nhận xét→media tag→bài tập→hoàn tất)):::new
    U5((Duyệt media — enforce tag + consent)):::new
    U6((Học phí/công nợ center mình)); U7((Nộp báo cáo tuần/tháng)):::new
    U8((Dashboard CENTER MÌNH — scope tự cắt, không thấy TT khác)):::new
    CM --> U1 & U5 & U7 & U8
    CS --> U2 & U3
    GV --> U4 & U3
    CA --> U6
    classDef new fill:#dfd,stroke:#080
```

### 7.3 Phụ huynh / Học sinh (portal)

```mermaid
flowchart LR
    PH([PARENT — 1 account]); CON([Site con N — profile, không studentId trên URL])
    V1((Chuyển site: PH ↔ con 1 ↔ con 2)):::new
    V2((/lich-hoc — TKB)):::new; V3((/bai-tap /trac-nghiem /nop-bai))
    V4((/hinh-anh — CHỈ media tag con)):::new; V5((/nhan-xet /thong-bao))
    V6((Báo vắng / xin học bù / chuyển lớp / bảo lưu))
    V7((Consent CLASS_MEDIA: cấp/thu hồi)):::new
    V8((Kích hoạt tài khoản qua email — tự đặt mật khẩu)):::new
    PH --> V1 & V6 & V7 & V8
    CON --> V2 & V3 & V4 & V5
    classDef new fill:#dfd,stroke:#080
```

### 7.4 Hệ thống tự động

```mermaid
flowchart LR
    CRON([Vercel Cron]); WH([Webhooks])
    C1((Dispatcher DomainEvent 1')):::new
    C2((SLA scan 15' — 7 rule §5.4)):::new
    C3((Ads Insights sync định kỳ)):::new
    C4((Ngày 01: Commission + CostAllocation DRAFT)):::new
    C5((Email queue 5' / reminders))
    W1((Messenger → Conversation/L1)):::new
    W2((GForm/landing → Lead))
    CRON --> C1 & C2 & C3 & C4 & C5
    WH --> W1 & W2
    classDef new fill:#dfd,stroke:#080
```

---

## §8 — AUDIT, BẢO MẬT & PII

**AuditLog hợp nhất:** `actorId · module · entityType · entityId · action · oldValues · newValues · orgUnitId · ip · userAgent · createdAt`.

**Bắt buộc audit:** lead (create/status/assign/handover/convert) · role/permission grant-revoke · student (create/update/transfer) · class (create/update/đổi GV) · invoice/payment/refund · parent activation · media (upload/duyệt/xóa) · attendance edit · cost allocation confirm · commission confirm.

**PII rules (enforce bằng scope + field visibility):**
```
TEACHER không mặc định xem SĐT phụ huynh · QC_MARKETING không xem PII nếu không cần
PARENT chỉ xem con mình · media chỉ hiển thị nếu tag đúng con · không expose studentId trên route
KHÔNG lưu giấy tờ tùy thân học viên · KHÔNG sinh trắc học/định vị học sinh
```

---

## §9 — ROADMAP CUỐI + PR SEQUENCING

```mermaid
gantt
    dateFormat YYYY-MM-DD
    title Lộ trình core (mốc tương đối — bắt đầu sau khi chốt Open Items)
    section A0 Foundation
    A0.1 OrgUnit + RoleDef/UserOrgRole + can() v2 song song :a1, 2026-06-09, 5d
    A0.2 Session gọn + ActorResolver + login chung           :a2, after a1, 4d
    A0.3 scopedDb + ESLint boundary                          :a3, after a2, 4d
    A0.4 DomainEvent outbox + dispatcher                     :a4, after a3, 4d
    A0.5 Module skeleton + AuditLog hợp nhất + UI roles      :a5, after a4, 3d
    section R1 CRM Messenger + Marketing
    R1.1 Messenger webhook + Inbox CRM                       :r1, after a5, 6d
    R1.2 Ads Insights sync + AdsInsightDaily                 :r2, after r1, 4d
    R1.3 L1→L2 + Handover HO→CS1/CS2                         :r3, after r2, 4d
    R1.4 SLA engine (7 rule)                                 :r4, after r3, 4d
    R1.5 Marketing dashboard                                 :r5, after r4, 5d
    R1.6 Cost allocation                                     :r6, after r5, 4d
    R1.7 Commission engine 4 tầng                            :r7, after r6, 6d
    R1.8 Export Excel + báo cáo tuần/tháng                   :r8, after r7, 4d
    section R2 SIS + Finance
    R2 Convert transaction · activation · Invoice/Payment/Debt · dedup UX :r9, after r8, 12d
    section R3 LMS offline
    R3 Curriculum version · Session · Attendance · checklist · Media+consent · Assignment/Quiz :r10, after r9, 14d
    section R4 Portal
    R4 Site PH + site con · route đẹp · lịch/bài tập/media/yêu cầu :r11, after r10, 10d
    section R5 HR
    R5 QR 30s + geofence NV + duyệt công                     :r12, after r11, 8d
```

### PR sequencing (giao việc trực tiếp)

| Nhóm | PR |
|---|---|
| **A0** | PR-A0-01 OrgUnit schema + seed HO/CS1/CS2 · 02 RoleDef/RolePermission/UserOrgRole + seed role §2.3 · 03 can() v2 + ActorResolver + legacy fallback · 04 scopedDb + tests chống lộ chéo center · 05 DomainEvent outbox + dispatcher · 06 AuditLog hợp nhất · 07 module skeleton + lint boundary |
| **R1 CRM** | PR-R1-01 FacebookPageMapping + MessengerConversation/Message · 02 `/api/webhooks/meta/messenger` · 03 `/admin/crm/messenger` inbox · 04 L1→L2 conversion · 05 Handover HO→Center · 06 SLA alerts · 07 Ads Insights sync · 08 Marketing dashboard · 09 Cost allocation · 10 Commission engine |
| **R2 SIS/Fin** | PR-SIS-01 Parent/Student/Relation cleanup · 02 convertLeadToEnrollment transaction · 03 Invoice/Payment auto-create · 04 Parent activation Resend · 05 Duplicate phone UX · 06 Transfer rules |
| **R3 LMS** | PR-LMS-01 Curriculum/Lesson version · 02 Class/Session/Progress · 03 Attendance summary · 04 Teacher checklist · 05 Media + tag + consent · 06 Assignment/Submission · 07 Quiz |
| **R4 Portal** | PR-PORTAL-01 route shell + active profile · 02 parent site · 03 child site · 04 requests (vắng/bù/chuyển/bảo lưu) |

### Chiến lược an toàn (hệ thống live)

1. **Additive trước, destructive sau** — `User.role/centerId` + matrix cũ giữ làm fallback; drop ở Phase C sau 2–3 tuần prod ổn.
2. `can()` v2 **chạy song song so khớp log** 1 tuần trước khi cắt.
3. **Boy-scout** di code vào `modules/` khi chạm — không mass-move.
4. Mỗi PR: `pnpm typecheck && lint && build && test` xanh (workflow push-main Phase A hiện hành — "PR" = chuỗi commit theo nhóm).
5. Rollback flags: can() fallback, dispatcher tắt được, scopedDb bypass cho hotfix.

---

## §10 — DEFINITION OF DONE

### DoD A0
1. Tạo role mới qua UI, dùng ngay — 0 deploy. 2. HO_ACCOUNTANT thấy toàn hệ thống; CENTER_ACCOUNTANT CS1 chỉ CS1 (test). 3. scopedDb chặn query thiếu filter (test). 4. Thêm consumer event = 1 dòng đăng ký. 5. Đổi quyền hiệu lực request kế tiếp. 6. Login chung redirect đúng 2 nhánh + route-policy tests xanh.

### DoD toàn dự án core (18 điểm)
1. HO/CS1/CS2 = OrgUnit, scope chạy đúng. 2. Login chung redirect đúng admin/hocvien. 3. Messenger Page HO tự tạo LEADS_1. 4. Sale Admin chuyển L1→L2 (SĐT + ghi chú). 5. L2 bàn giao CS1/CS2 theo SLA. 6. Chốt L3 = transaction tạo Student/Parent/Enrollment/Invoice/Payment. 7. Parent activation không mật khẩu mặc định. 8. Marketing dashboard: spend, L1/L2/L3, CPL, CPA, ROAS. 9. Cost allocation theo L2 hoạt động. 10. Commission 4 tầng tính từ L3. 11. LMS offline đủ chuỗi khóa→giáo trình→lớp→buổi→điểm danh→bài tập→media. 12. Portal có site PH + site từng con, không lộ studentId. 13. PH chỉ xem ảnh/video của con. 14. Không lưu giấy tờ tùy thân. 15. Không có AI camera/sinh trắc/định vị học sinh. 16. Audit phủ nghiệp vụ nhạy cảm. 17. CENTER_MANAGER CS1 không xem được CS2 và ngược lại. 18. SUPER_ADMIN/HO xem toàn hệ thống theo quyền.

---

## §11 — OPEN ITEMS (chốt trước khi code sâu — đã có default)

| # | Câu hỏi | Default đang dùng |
|---|---|---|
| OI-1 | HO là OrgUnit độc lập để tính chi phí/lương? | **Có** |
| OI-2 | Chỉ SUPER_ADMIN tạo/sửa role? | **Đúng** (audit + lý do bắt buộc) |
| OI-3 | Page HO token + Meta App Review? | Chưa → build DB/UI trước, webhook bật sau (nhập tay fallback) |
| OI-4 | File Excel mẫu hoa hồng hiện hành | **Cần gửi** — chặn R1.7/R1.8 |
| OI-5 | Khóa kỳ phân bổ sau CONFIRMED? | **Có** — chỉ REOPEN bởi SUPER_ADMIN/HO_ACCOUNTANT |
| OI-6 | Parent activation: email Resend trước, SMS brandname sau? | **Đúng** |
| OI-7 | Câu hỏi nhóm B còn lại (`0-yeucau/1-pm-tiep-nhan/03`): thời điểm L3 (đợt 1?), tái tục, referral, clawback, đổi sale | Default theo phương án đề xuất trong file 03 |

---

## §12 — BẢNG TRƯỚC/SAU (điều hành)

| Tiêu chí | TRƯỚC | SAU |
|---|---|---|
| Thêm role | Migration + code + deploy | UI, vài phút, audit |
| Hội sở | Không biểu diễn được | OrgUnit tree + cascade |
| Kiêm nhiệm HO+CS2 / dạy thay | Không mô hình hóa | UserOrgRole + EmployeeOrgAssignment |
| Lộ dữ liệu chéo TT | Phụ thuộc dev nhớ filter | scopedDb enforced + test |
| Login | Riêng từng host | Cổng chung tự redirect |
| Lead Messenger | Không có | Inbox CRM + L1 realtime + SLA 5' |
| Marketing ROI | Không đo được | Dashboard spend/CPL/CPA/ROAS + cost allocation |
| Hoa hồng | Tính tay Excel | Engine 4 tầng + duyệt + audit |
| Thêm consumer nghiệp vụ | Mổ action gốc | 1 dòng đăng ký handler |
| Thêm module/model | Schema 4000 dòng + god-files | Module template + multi-file schema |
| Đổi quyền hiệu lực | Bump token/re-login | Ngay request kế tiếp |
| Privacy trẻ em | Chưa có consent ảnh | Tag bắt buộc + consent + không sinh trắc/định vị |
| Franchise/SaaS sau này | Viết lại | OrgUnit subtree = 80% nền |

---

## §13 — KẾT LUẬN

```
Modular Monolith
+ Organization Hierarchy HO/CS1/CS2 (OrgUnit tree)
+ Dynamic RBAC/ABAC 6-mức scope + per-user grant
+ Messenger-first CRM theo LEADS_1/2/3 + SLA engine
+ Marketing Ads dashboard + Cost allocation + Commission 4 tầng
+ LMS offline Sata 1–8 (curriculum version, checklist GV, media tag+consent)
+ Finance transaction-safe (Invoice/Payment/Debt)
+ Portal hocvien: site phụ huynh + site từng con, không lộ studentId
+ Login chung satarobo.vn/login
+ Audit hợp nhất + Privacy-first dữ liệu trẻ em
```

KHÔNG đưa lại vào core: AI camera, sinh trắc học, định vị học sinh, Web3/NFT/blockchain, marketplace, student login riêng, teacher domain riêng, online video LMS, AI learning path, AI prediction.

> Bước kế tiếp khi anh chốt Open Items §11: cập nhật task breakdown trong `0-yeucau/3-ke-hoach-trien-khai/` theo PR sequencing §9 → bắt đầu **PR-A0-01**.
