# Roadmap triển khai theo Release

> ⚠️ **SUPERSEDED (2026-06-05):** Roadmap CHỐT hiện tại nằm ở `Document/2-architecture-design/15-final-architecture-blueprint.md` §9 (A0 → R1 CRM Messenger/Marketing/Commission → R2 SIS/Finance → R3 LMS → R4 Portal → R5 HR). Khác biệt chính so với file này: **Zalo OA/ZNS + SataCoin quà + payment gateway lùi về backlog sau core**; commission nằm trong R1; thêm Ads Insights sync + Messenger inbox. File này giữ làm tham chiếu chi tiết task R2-cũ (trùng lịch/TKB/consent — nay phân bổ vào R3/R4 mới).

> **Input:** 2 gap analysis + user stories (`2-ba-phan-tich/`).
> **Điều kiện khởi động:** khách trả lời `1-pm-tiep-nhan/03-cau-hoi-xac-nhan-khach-hang.md` (tối thiểu nhóm B trước R1).
> Ước lượng theo 1 dev chính (mô hình hiện tại) — chạy tuần tự, mỗi release verify + demo trước khi sang release sau.

---

## Tổng quan

```mermaid
gantt
    dateFormat  YYYY-MM-DD
    title Roadmap (mốc tương đối — bắt đầu sau khi chốt câu hỏi B)
    section R1 — SR217 Tuyển sinh
    R1.1 Phễu + nhập liệu QC          :r11, 2026-06-09, 5d
    R1.2 SLA engine + handover        :r12, after r11, 5d
    R1.3 Commission Engine            :r13, after r12, 7d
    R1.4 Cost Allocation              :r14, after r13, 4d
    R1.5 Dashboard + báo cáo + export :r15, after r14, 6d
    section R2 — Vận hành đào tạo
    R2.1 Trùng lịch + sức chứa (M1)   :r21, after r15, 4d
    R2.2 TKB Portal (M2)              :r22, after r21, 3d
    R2.3 Consent dữ liệu (M3)         :r23, after r22, 4d
    section R3 — Trải nghiệm PH
    R3.1 Zalo OA live (S1)            :r31, after r23, 4d
    R3.2 SataCoin portal + quà (S2)   :r32, after r31, 5d
    R3.3 PH sửa hồ sơ con (S3)        :r33, after r32, 2d
    section R4 — Báo cáo & hồ sơ
    R4.1 Dashboard 3 tầng (S4)        :r41, after r33, 6d
    R4.2 Hồ sơ năng lực (S5)          :r42, after r41, 4d
    R4.3 NPS→KPI (S6)                 :r43, after r42, 3d
```

## A0 — Architecture Foundation (≈ 3 tuần) — ĐỀ XUẤT CHÈN TRƯỚC R1 ⚠️ chờ duyệt

> Chi tiết BẢN CHỐT: `Document/2-architecture-design/15-final-architecture-blueprint.md` (hợp nhất Doc 13 + proposal CEO + review Doc 14). Lý do chèn trước: Commission/SLA/Cost-Allocation cần phân biệt **Hội sở (HO) vs Trung tâm** và scope dữ liệu enforced — xây trên nền role-enum hiện tại sẽ phải đập sửa ngay sau đó.

| Sprint | Nội dung |
|---|---|
| A0.1 | `OrgUnit` (HO→Center) + role động (`RoleDef/RolePermission/UserOrgRole`) + `can()` v2 song song matrix cũ |
| A0.2 | Session gọn (userId + sessionVersion) + Actor resolver, gỡ legacy shim |
| A0.3 | `scopedDb` enforced scope theo OrgUnit subtree + ESLint rule |
| A0.4 | `DomainEvent` outbox + dispatcher + chuyển 2 luồng `order.confirmed`, `attendance.marked`; UI `/admin/roles` |
| A0.5 | Khung `modules/` + ESLint boundary + AuditLog hợp nhất + Notifier interface |

Phương án B (nếu SR217 quá gấp): R1.1–R1.2 chạy trên nền cũ song song A0, chấp nhận refactor nhỏ khi merge.

## R1 — SR217 Compliance (≈ 5–6 tuần) — ƯU TIÊN CAO NHẤT

| Sprint | Nội dung | Epic/US | Điều kiện |
|---|---|---|---|
| R1.1 | **Messenger webhook → `PageInboundEvent` (L1 realtime)** + `AdsDailyStat` (chi phí + L1 kênh nhập tay) + trang nhập/import QC + timestamps phễu trên Lead (`qualifiedAt/handedAt/receivedConfirmedAt/assignedAt/firstContactAt`, `commissionSource`, `adminId`) + flow xác nhận tiếp nhận | SR-A (US-SRA-0,1,2) | **FB page token + App Review** (xin ngay từ đầu) |
| R1.2 | SLA engine (cron 15' + StaffNotification + email — SLA-0 phản hồi 15', bàn giao 4h, phân công 30', liên hệ 3h), màn hình "lead quá hạn" | SR-A (US-SRA-3) | B9 |
| R1.3 | `CommissionPeriod/Item/RateConfig` + job tính 4 tầng + duyệt + trang "hoa hồng của tôi" + audit + clawback | SR-B (US-SRB-1,2,3) | **B1–B5 đã chốt** |
| R1.4 | `CostAllocationPeriod/Line` + job CPL/CPA + duyệt kế toán + alert ngày 05 | SR-C (US-SRC-1) | B6 |
| R1.5 | Dashboard funnel L1/L2/L3 + CPL/CPA + DS theo Sale; nộp báo cáo tuần/tháng + alert; export Excel 3 format | SR-C (US-SRC-2,3) | **B7 file mẫu** |

**Definition of Done R1:** chạy song song 1 tháng với 3 file Excel — số liệu khớp 100%; Kế toán xác nhận bảng hoa hồng + phân bổ tháng đầu; nghiệm thu theo mục 6 của gap analysis SR217.

## R2 — Vận hành đào tạo (≈ 2 tuần)

R2.1 `lib/classes/conflict.ts` + tích hợp 3 server actions (US-M1-1) → R2.2 `/portal/lich-hoc` (US-M2-1) → R2.3 `StudentConsent` + enforce media + UI portal (US-M3-1).

## R3 — Trải nghiệm phụ huynh (≈ 2.5 tuần)

R3.1 Zalo live (cần C4: token + ZNS template duyệt — **xin trước 2 tuần** vì Zalo duyệt lâu) → R3.2 RewardItem/Redemption + portal SataCoin → R3.3 whitelist field PH sửa.

## R4 — Báo cáo & hồ sơ (≈ 2.5 tuần)

R4.1 Dashboard 3 tầng (tái dùng component R1.5) → R4.2 trang + PDF hồ sơ năng lực → R4.3 báo cáo NPS theo nhân sự (cần C8).

## Backlog COULD (xếp lịch sau R4, theo phản hồi vận hành)

Xếp lớp tự động (cần C3 phỏng vấn giáo vụ) · thi giám sát mức 1 · share học bạ · MISA sync (cần C5) · cổng thanh toán (cần C6) · PWA + push · access log đọc.

## Track R&D (song song, không chiếm sprint dev)

Chỉ còn: **marketplace khóa học** · **multi-tenant đóng gói cho đối tác** — mỗi chủ đề 1 doc nghiên cứu khi khách kích hoạt. (Mọi hạng mục AI + NFT/blockchain đã bị khách loại khỏi scope 2026-06-05; nhu cầu dự báo làm rule-based trong backlog thường.)

## Quản trị rủi ro release

| Rủi ro | Phòng ngừa |
|---|---|
| **Facebook App Review** (quyền `pages_messaging`/webhook messages) kéo dài → L1 realtime chậm | Nộp review ngay tuần đầu R1.1; trong lúc chờ: L1 chạy bằng nhập/import file QC (đường nhập tay là fallback vĩnh viễn cho kênh không có webhook) |
| Khách chậm trả lời nhóm B → R1.3 đứng | R1.1–R1.2 không phụ thuộc B — khởi động trước; chốt B muộn nhất khi R1.2 xong |
| File Excel mẫu (B7) đến muộn | Export để cuối R1.5; dashboard không chờ |
| Zalo ZNS duyệt template lâu | Nộp template ngay khi vào R2 (trước R3.1 ~2 tuần) |
| Số liệu tháng song song lệch Excel | Lệch = bug hoặc khác định nghĩa → log đối chiếu từng lead, họp chốt với kế toán |
| Hoa hồng sai → tranh chấp | Không trả theo bảng auto cho tới khi 1 kỳ khớp thủ công 100%; audit log đầy đủ |

## Nhịp làm việc (theo quy ước repo)

- Mỗi sprint item = chuỗi commit nhỏ push thẳng `main` (workflow Phase A), verify `pnpm typecheck && lint && build` + smoke trước khi báo PASS.
- Mỗi release kết thúc: demo cho khách + cập nhật `Document/` (doc 3/7/8/9 nếu schema/API/flow đổi).
